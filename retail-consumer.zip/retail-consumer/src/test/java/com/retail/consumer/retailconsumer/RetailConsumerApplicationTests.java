package com.retail.consumer.retailconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetailConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
